"""Run ONLY inside an authorized Linux cloud VM/notebook. Never on the user's PC.

python audio-cloud-bootstrap.py --cloud-confirmed
python audio-cloud-bootstrap.py --cloud-confirmed --install-models

Stop if a provider requests authentication or acceptance of model terms. This
script does not accept terms or supply credentials on anyone's behalf.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

PIN = "9b679edb3032d6b9df25f0cf4fab12b552ae4b61"
REPO = "https://github.com/AIEGOBOT/agent-audio.git"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cloud-confirmed", action="store_true")
    parser.add_argument("--install-models", action="store_true")
    parser.add_argument("--workdir", default="/tmp/umc-audio-cloud")
    args = parser.parse_args()
    if platform.system() != "Linux" or not args.cloud_confirmed:
        raise SystemExit("Refused: use an authorized Linux CLOUD session with --cloud-confirmed.")
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11+ required.")
    if not shutil.which("git"):
        raise SystemExit("Git is required on the cloud host.")
    root = Path(args.workdir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    repo = root / "agent-audio"
    env = os.environ.copy()
    env["AGENT_AUDIO_HOME"] = str(root / "runtime")
    def run(command, cwd=None):
        subprocess.run(command, cwd=cwd, env=env, check=True)
    if not repo.exists():
        run(["git", "clone", REPO, str(repo)])
        run(["git", "checkout", "--detach", PIN], repo)
    else:
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
        dirty = subprocess.check_output(["git", "status", "--porcelain"], cwd=repo, text=True).strip()
        if head != PIN or dirty:
            raise SystemExit("Existing checkout differs; preserved. Choose a new --workdir.")
    # Colab's default Python can be newer than the pinned runtime supports.
    run([sys.executable, "-m", "pip", "install", "uv"])
    uv = [sys.executable, "-m", "uv"]
    run(uv + ["sync", "--frozen", "--python", "3.12"], repo)
    run(uv + ["run", "--frozen", "python", "install/bootstrap.py", "--doctor"], repo)
    if args.install_models:
        free = shutil.disk_usage(root).free
        if free < 25 * 1024**3:
            raise SystemExit("Less than 25 GiB free disk. No models installed; choose another cloud host.")
        run(uv + ["run", "--frozen", "python", "install/bootstrap.py", "--runtime-only"], repo)
    print(json.dumps({"agent_audio_commit": PIN, "checkout": str(repo),
                      "AGENT_AUDIO_HOME": env["AGENT_AUDIO_HOME"],
                      "generation_verified": False, "client_registration": "not requested"}, indent=2))


if __name__ == "__main__":
    main()
