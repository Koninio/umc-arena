"""Run only in the Colab runtime after Agent Audio generation completes.

Every output is edited from the generated WAVs; no oscillator/synthetic replacement.
Exports browser OGGs, original WAVs, checksums, and measurable audio QA.
"""
import hashlib
import json
from pathlib import Path
import platform
import shutil
import zipfile

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

if platform.system() != "Linux" or not Path("/content").is_dir():
    raise SystemExit("Cloud Colab runtime only")

ROOT = Path("/content/umc-audio-export")
OUT = ROOT / "dist/assets/audio"
OUT.mkdir(parents=True, exist_ok=True)
ORIGINAL = ROOT / "audio-originals"
ORIGINAL.mkdir(exist_ok=True)
sources = {}
records = []
assets = []
RATE = 44100

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fade(x, seconds=.015):
    x = x.copy()
    n = min(int(RATE * seconds), len(x) // 3)
    if n:
        ramp = np.linspace(0, 1, n)[:, None]
        x[:n] *= ramp
        x[-n:] *= ramp[::-1]
    return x

def normalize(x, peak=.80):
    level = float(np.max(np.abs(x)))
    return x * min(4, peak / max(level, 1e-8))

def trim(x):
    envelope = np.max(np.abs(x), axis=1)
    indices = np.flatnonzero(envelope > max(.001, float(envelope.max()) * .025))
    if not len(indices):
        raise ValueError("Generated audio is silent")
    a = max(0, indices[0] - int(.015 * RATE))
    b = min(len(x), indices[-1] + int(.10 * RATE))
    return x[a:b]

def pitch(x, semitones):
    # Resampling changes duration and pitch together, intentionally for short SFX.
    denominator = int(1000 * 2 ** (semitones / 12))
    return resample_poly(x, 1000, denominator, axis=0)

def emit(name, x, base, operation, loop=False):
    x = normalize(fade(x, .01 if not loop else .08), .72 if loop else .80)
    path = OUT / (name + ".ogg")
    sf.write(path, x, RATE, format="OGG", subtype="VORBIS")
    decoded, rate = sf.read(path, always_2d=True)
    assert rate == RATE and np.isfinite(decoded).all()
    peak = float(np.max(np.abs(decoded)))
    rms = float(np.sqrt(np.mean(decoded ** 2)))
    if rms < .0001 or peak > 1:
        raise ValueError(f"Output level check failed: {name}")
    assets.append({"id": name, "file": f"assets/audio/{name}.ogg", "loop": loop})
    records.append({"id": name, "source": base, "processing": operation,
                    "seconds": round(len(decoded)/rate, 4), "peak": round(peak, 5),
                    "rms": round(rms, 5), "sha256": digest(path)})

for directory in [Path('/content/umc-audio-test-01'), *sorted(Path('/content').glob('umc-audio-release-*'))]:
    for path in directory.glob('*.wav'):
        x, rate = sf.read(path, always_2d=True)
        if rate != RATE or not np.isfinite(x).all() or np.max(np.abs(x)) < .001:
            raise ValueError(f"Invalid generated WAV: {path.name}")
        sources[path.stem] = x
        shutil.copy2(path, ORIGINAL / path.name)
    report = directory / 'generation-report.json'
    if report.exists():
        shutil.copy2(report, ORIGINAL / (directory.name + '-report.json'))

expected = json.loads(Path('/content/audio-prompts.json').read_text())['assets']
missing = [a['id'] for a in expected if a['id'] not in sources]
if missing:
    raise ValueError('Generation incomplete: ' + ', '.join(missing))

for name, x in sources.items():
    if name.startswith('bgm-'):
        # Equal-power overlap removes abrupt start/end cuts. Short endpoint fades
        # suppress encoding clicks; musical loop coherence still needs listening.
        n = RATE
        phase = np.linspace(0, np.pi/2, n)[:, None]
        overlap = x[-n:] * np.cos(phase) + x[:n] * np.sin(phase)
        x = np.concatenate([overlap, x[n:-n]])
        emit(name, x, name, '1s overlap crossfade; endpoint fade; normalization', True)
    elif name == 'step':
        # Take one strongest 180ms impact rather than replay all four footsteps.
        energy = np.convolve(np.mean(x*x, axis=1), np.ones(441)/441, mode='same')
        onset = max(0, int(np.argmax(energy)) - int(.045 * RATE))
        x = x[onset:onset+int(.18*RATE)]
        step_clip = x.copy()
        emit(name, x, name, 'single 180ms footstep extraction')
    else:
        emit(name, trim(x), name, 'silence trim, short fade, peak normalization')

for school in ['ice', 'fire', 'blade', 'dark', 'lightning']:
    cast = trim(sources[school+'-cast'])
    impact = trim(sources[school+'-impact'])
    emit(school+'-basic', pitch(cast, 4)[:int(.4*RATE)], school+'-cast', 'short high-pitch basic attack')
    for slot, shift in enumerate([0, 3, -3, -5, 5]):
        c = pitch(cast, shift)
        h = pitch(impact, shift)
        if slot == 1:
            delay = int(.065*RATE)
            triple = np.zeros((len(c)+2*delay, c.shape[1]))
            for k in range(3): triple[k*delay:k*delay+len(c)] += c * .5
            c = triple
        emit(f'{school}-{slot}-cast', c, school+'-cast', f'slot variation: pitch {shift}, fan layering when slot1')
        emit(f'{school}-{slot}-impact', h, school+'-impact', f'pitch {shift}')
        charge = pitch(cast[::-1], shift-2)[:int(1.3*RATE)].copy()
        charge *= np.linspace(.05, .85, len(charge))[:, None]
        emit(f'{school}-{slot}-charge', charge, school+'-cast', 'reverse swell, pitch, 1.3s maximum')
        travel = pitch(cast, shift-5)
        travel = travel[len(travel)//4:][:int(.7*RATE)]
        emit(f'{school}-{slot}-travel', travel, school+'-cast', 'lower-pitch tail, 0.7s maximum')

emit('jump', pitch(trim(sources['dash']), 5)[:int(.35*RATE)], 'dash', 'short higher-pitch rise')
emit('land', pitch(step_clip, -4)[:int(.22*RATE)], 'step', 'short low-pitch landing from extracted footstep')
emit('parry-ready', pitch(trim(sources['parry']), -3)[:int(.25*RATE)], 'parry', 'short low-pitch ready cue')

manifest = {'status':'generated_in_cloud', 'generator':'https://github.com/AIEGOBOT/agent-audio',
            'assets':assets, 'note':'20 Agent Audio source clips; skill variants edited from those clips in Colab.'}
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2))
report = {'agent_audio_commit':'9b679edb3032d6b9df25f0cf4fab12b552ae4b61',
          'runtime_commit':'779434a908193105335fd8d833418603625b2859',
          'model':'stable-audio-3-medium / TFLite CPU', 'environment':'Google Colab Linux CPU',
          'listening_verified':False, 'qa':'finite samples, non-silent RMS, peak below 1, decode checks',
          'source_assets':[{'file':p.name,'sha256':digest(p)} for p in ORIGINAL.glob('*.wav')],
          'derived_assets':records}
docs = ROOT/'docs'; docs.mkdir(exist_ok=True)
cpu_patch = Path('/content/umc-cpu-patch.json')
if cpu_patch.exists():
    report['runtime_adjustment'] = json.loads(cpu_patch.read_text())
(docs/'audio-provenance.json').write_text(json.dumps(report, indent=2))
shutil.copy2('/content/audio-prompts.json', docs/'audio-prompts.json')
archive = Path('/content/umc-cloud-audio.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for path in ROOT.rglob('*'):
        if path.is_file(): z.write(path, path.relative_to(ROOT))
print(json.dumps({'outputs':len(assets), 'source_clips':len(sources), 'zip_bytes':archive.stat().st_size,
                  'zip_sha256':digest(archive), 'listening_verified':False}))
