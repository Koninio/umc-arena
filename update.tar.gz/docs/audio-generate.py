"""Cloud-only Agent Audio MCP client. Run using agent-audio/.venv/bin/python.

First run uses only ui-match (3 s). Use --ids all after that succeeds.
"""
import argparse
import asyncio
from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import wave


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cloud-confirmed", action="store_true")
    parser.add_argument("--root", default="/tmp/umc-audio-cloud")
    parser.add_argument("--manifest", default=str(Path(__file__).with_name("audio-prompts.json")))
    parser.add_argument("--out", required=True, help="A NEW directory on the cloud filesystem")
    parser.add_argument("--ids", default="ui-match", help="Comma-separated IDs or all")
    args = parser.parse_args()
    if platform.system() != "Linux" or not args.cloud_confirmed:
        raise SystemExit("Refused: cloud Linux only. Explicit --cloud-confirmed is required.")
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    root = Path(args.root).resolve()
    output = Path(args.out).resolve()
    output.mkdir(parents=True, exist_ok=False)
    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    selected = manifest["assets"] if args.ids == "all" else [a for a in manifest["assets"] if a["id"] in args.ids.split(",")]
    if not selected:
        raise SystemExit("No matching audio IDs.")
    env = os.environ.copy()
    env["AGENT_AUDIO_HOME"] = str(root / "runtime")
    server = StdioServerParameters(command=str(root / "agent-audio/.venv/bin/python"),
                                  args=["-I", "-m", "agent_audio.mcp_server"], env=env)
    report = {"generator": "AIEGOBOT/agent-audio", "listening_verified": False, "assets": []}
    try:
        async with stdio_client(server) as (read, write):
            async with ClientSession(read, write, read_timeout_seconds=timedelta(seconds=1800)) as session:
                await session.initialize()
                status = await session.call_tool("audio_status", {})
                if status.isError:
                    raise RuntimeError("audio_status failed; inspect cloud runtime locally.")
                report["status"] = [x.text for x in status.content if hasattr(x, "text")]
                for item in selected:
                    target = output / (item["id"] + ".wav")
                    result = await session.call_tool("generate_audio", {
                        "prompt": item["prompt"], "seconds": item["seconds"], "output_path": str(target)})
                    if result.isError or not target.is_file() or target.stat().st_size <= 44:
                        print(result.model_dump_json(), flush=True)
                        raise RuntimeError("Generation failed for " + item["id"] + "; no substitute audio created.")
                    record = {"id": item["id"], "file": target.name, "bytes": target.stat().st_size,
                              "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "listening_verified": False}
                    try:
                        with wave.open(str(target), "rb") as wav:
                            record.update(seconds=wav.getnframes() / wav.getframerate(),
                                          sample_rate=wav.getframerate(), channels=wav.getnchannels(),
                                          sample_width=wav.getsampwidth())
                    except wave.Error as error:
                        record["metadata_check_error"] = str(error)
                    report["assets"].append(record)
                    (output / "generation-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
                    print(item["id"] + ": generated; listening and loop-boundary checks pending", flush=True)
    finally:
        (output / "generation-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")


if __name__ == "__main__":
    asyncio.run(main())
