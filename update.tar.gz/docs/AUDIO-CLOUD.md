# UMC 클라우드 오디오 제작

2026-10-17 Google Colab 무료 Linux CPU 환경에 Agent Audio를 설치하고 원본 음원 20개를 생성했습니다. 사용자 PC에는 모델·Agent Audio 런타임을 설치하지 않았습니다. 게임용 변형과 OGG 변환도 같은 클라우드에서 수행합니다.

## 환경과 출처

- 노트북: https://colab.research.google.com/drive/1IGaOUf1uSZysr5_PUe61e8TvO7txj2Jr
- Agent Audio: https://github.com/AIEGOBOT/agent-audio
- Agent Audio commit: `9b679edb3032d6b9df25f0cf4fab12b552ae4b61`
- Stable Audio runtime commit: `779434a908193105335fd8d833418603625b2859`
- 모델: Stable Audio 3 medium, TFLite CPU, 8 inference steps.
- 할당 자원: CPU 2개, RAM 12.67 GB. GPU·유료 요금제를 사용하지 않았습니다.
- 모델은 인증·약관 동의 화면 없이 다운로드됐습니다. 사용자 대신 약관을 수락하지 않았습니다. 재실행 중 서비스가 인증이나 동의를 요구하면 사용자가 해당 화면에서 처리해야 합니다.

## 재현

`UMC-Agent-Audio-Reproduce.ipynb`를 Colab에서 열면 설치·생성·후처리·다운로드 코드를 함께 실행할 수 있습니다. 이 노트북은 생성에 성공한 스크립트와 고정된 소스 커밋을 포함합니다.

아래 스크립트는 **클라우드 Linux에서만** 실행합니다. Colab에서는 먼저 `audio-cloud-bootstrap.py`, `audio-generate.py`, `audio-prompts.json`, `audio-postprocess.py`를 `/content`로 올립니다. Python 3.12를 사용하는 uv 환경을 설치합니다.

```sh
python audio-cloud-bootstrap.py --cloud-confirmed --install-models
/tmp/umc-audio-cloud/agent-audio/.venv/bin/python audio-generate.py --cloud-confirmed --out /content/umc-audio-test-01
/tmp/umc-audio-cloud/agent-audio/.venv/bin/python audio-generate.py --cloud-confirmed --ids all --out /content/umc-audio-release-01
```

출력 디렉터리는 새 경로를 사용합니다. 첫 명령은 매칭음 1개로 시험합니다. 배치 실패 시 성공한 WAV를 보존하고 `--ids`로 미완료 항목만 지정합니다. 생성 보고서는 파일별로 저장하며, 재시도 경로는 후처리 스크립트의 입력 디렉터리에 포함해야 합니다.

## 음원 편집과 검증

`audio-prompts.json`은 매칭, 5계열 발사·피격, 발걸음, 대시, 점멸, 패링, 취소, 자기장, 승리, 로비·전투 BGM의 원본 20개를 정의합니다. `audio-postprocess.py`는 이 원본에서 스킬 25개의 충전·발사·이동·피격 변형, 기본 공격, 점프·착지·패링 준비음을 만듭니다. 모든 편집은 Colab에서 수행합니다. 별도 발진기로 만든 대체 음원은 사용하지 않습니다.

후처리는 무음 잘라내기, 단일 발걸음 추출, 음높이·레이어 조정, 페이드, BGM 경계 겹치기, 음량 정리, OGG 저장을 수행합니다. 유한한 샘플, 무음 여부, 최대 진폭, 재디코딩, SHA-256을 검사합니다. 원본 WAV와 제작 기록은 보존합니다.

파일·파형 검증과 청취 검수는 별개입니다. 실제 청취로 확인하지 않은 프롬프트 일치와 음악적 루프 자연스러움은 `listening_verified: false`로 기록합니다. 완성된 웹 파일 목록은 `dist/assets/audio/manifest.json`, 출처와 측정치는 `docs/audio-provenance.json`에서 확인합니다.

모델·캐시·토큰은 게임 서버나 GitHub에 업로드하지 않습니다. Colab은 오디오 제작에만 쓰며 게임 서버는 Render에서 실행합니다.
