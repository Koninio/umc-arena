import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {WebSocketServer,WebSocket} from 'ws';
import {createMatch,step,snapshot,setInput,action,STEP} from '../dist/engine.js';
const root=path.resolve(fileURLToPath(new URL('../dist/',import.meta.url)));
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png','.wav':'audio/wav','.ogg':'audio/ogg'};
export function createServer({port=Number(process.env.PORT)||3000,host='0.0.0.0'}={}){
 const rooms=new Map(),clients=new Set();let queue=null;
 const server=http.createServer(async(req,res)=>{
  if(req.url==='/config.js'){res.writeHead(200,{'Content-Type':'text/javascript','Cache-Control':'no-store'});return res.end("export const SERVER_URL=location.origin;export const AUDIO_MANIFEST='/assets/audio/manifest.json';");}
  if(req.url==='/health'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'});return res.end(JSON.stringify({ok:true,protocol:1,activeRooms:rooms.size}));}
  try{const url=new URL(req.url,'http://localhost'),name=decodeURIComponent(url.pathname),file=path.resolve(root,'.'+(name==='/'?'/index.html':name));if(!file.startsWith(root+path.sep)&&file!==path.join(root,'index.html'))throw Error();const data=await readFile(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'});res.end(data)}catch{res.writeHead(404);res.end('Not found')}
 });
 const wss=new WebSocketServer({server,path:'/ws',maxPayload:2048,perMessageDeflate:false});
 const send=(c,v)=>{if(c.ws.readyState===WebSocket.OPEN&&c.ws.bufferedAmount<100000)c.ws.send(JSON.stringify(v));};
 function closeRoom(room,leaver){if(!room)return;for(const c of room.members){c.room=null;if(c!==leaver)send(c,{type:'opponent_left',message:'상대의 연결이 종료되었습니다. 로비에서 다시 만날 수 있습니다.'});}rooms.delete(room.code);if(queue===room)queue=null;}
 function join(room,c){room.members.push(c);c.room=room;send(c,{type:'room',code:room.code,waiting:room.members.length===1});if(room.members.length===2){room.match=createMatch(room.members[0].school,room.members[1].school,randomBytes(4).readUInt32LE());room.started=performance.now();for(let i=0;i<2;i++){room.members[i].id='p'+(i+1);send(room.members[i],{type:'start',id:room.members[i].id,code:room.code});}if(queue===room)queue=null;}}
 wss.on('connection',(ws,req)=>{
  if(clients.size>=100){ws.close(1013,'Server full');return}
  const c={ws,id:null,room:null,school:0,lastInput:performance.now(),lastSeq:-1,budget:120,lastBudget:performance.now(),alive:true};clients.add(c);send(c,{type:'hello',protocol:1});
  ws.on('pong',()=>c.alive=true);
  ws.on('message',data=>{
   const now=performance.now();c.budget=Math.min(120,c.budget+(now-c.lastBudget)*.1);c.lastBudget=now;if(--c.budget<0){ws.close(1008,'Rate limit');return}
   let msg;try{msg=JSON.parse(data.toString())}catch{return}if(!msg||typeof msg!=='object')return;
   if(msg.type==='ping'){send(c,{type:'pong',sent:msg.sent});return}
   if(msg.type==='leave'){closeRoom(c.room,c);c.lastSeq=-1;return}
   if(msg.type==='queue'||msg.type==='create'||msg.type==='join'){
    if(c.room)return;if(!Number.isInteger(msg.school)||msg.school<0||msg.school>4)return;c.school=msg.school;
    if(msg.type==='join'){const room=rooms.get(String(msg.code).toUpperCase());if(!room||room.members.length>=2){send(c,{type:'error',message:'입장 가능한 방을 찾지 못했습니다.'});return}join(room,c);return;}
    if(msg.type==='queue'&&queue&&queue.members.length===1){join(queue,c);return}
    if(rooms.size>=50){send(c,{type:'error',message:'서버가 가득 찼습니다. 잠시 뒤 다시 시도해주세요.'});return}
    let code;do{code=randomBytes(4).toString('hex').slice(0,6).toUpperCase()}while(rooms.has(code));const room={code,members:[],match:null,created:now};rooms.set(code,room);join(room,c);if(msg.type==='queue')queue=room;return;
   }
   const m=c.room?.match;if(!m||m.ended)return;
   if(!Number.isSafeInteger(msg.seq)||msg.seq<=c.lastSeq)return;c.lastSeq=msg.seq;
   if(msg.type==='input'){setInput(m,c.id,msg);c.lastInput=now}
   if(msg.type==='action'&&['press','release','cancel','dash','blink','parry','jump','basic'].includes(msg.action)){action(m,c.id,msg.action,msg.slot);c.lastInput=now}
  });
  ws.on('close',()=>{closeRoom(c.room,c);clients.delete(c)});ws.on('error',()=>{});
 });
 let last=performance.now(),acc=0;
 const timer=setInterval(()=>{const now=performance.now();acc+=Math.min(.1,(now-last)/1000);last=now;while(acc>=STEP){for(const room of rooms.values()){if(!room.match||room.reported)continue;for(const c of room.members)if(now-c.lastInput>300)setInput(room.match,c.id,{x:0,y:0});step(room.match);if(room.match.tick%3===0||room.match.ended)for(const c of room.members)send(c,{type:'state',state:snapshot(room.match,c.id)});if(room.match.ended){room.reported=true;room.finished=now;}}acc-=STEP;}for(const room of rooms.values())if((!room.match&&now-room.created>600000)||(room.reported&&now-room.finished>300000))closeRoom(room);},8);
 const heartbeat=setInterval(()=>{for(const c of clients){if(!c.alive){c.ws.terminate();continue}c.alive=false;c.ws.ping();}},15000);
 server.listen(port,host);
 return {server,rooms,wss,close:async()=>{clearInterval(timer);clearInterval(heartbeat);for(const c of clients)c.ws.terminate();await new Promise(r=>wss.close(r));await new Promise(r=>server.close(r));}};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){const app=createServer();app.server.on('listening',()=>console.log(`UMC server ready on port ${app.server.address().port}`));}
