import assert from 'node:assert/strict';
import {once} from 'node:events';
import {WebSocket} from 'ws';
const base=process.argv[2];
if(!base?.startsWith('https://')) throw Error('Pass the deployed HTTPS origin');
const until=async(fn,timeout=15000)=>{const start=Date.now();while(!fn()){if(Date.now()-start>timeout)throw Error('Timed out waiting for cloud response');await new Promise(r=>setTimeout(r,25));}return fn();};
const health=await fetch(base+'/health');assert.equal(health.status,200);assert.equal((await health.json()).protocol,1);
const html=await fetch(base+'/');assert.match(await html.text(),/UMC/);
const endpoint=base.replace(/^https:/,'wss:')+'/ws';
const client=()=>{const ws=new WebSocket(endpoint),messages=[],arrivals=[];ws.on('message',data=>{const message=JSON.parse(data);messages.push(message);if(message.type==='state')arrivals.push(performance.now());});return {ws,messages,arrivals,send:value=>ws.send(JSON.stringify(value))};};
const a=client(),b=client();
let sustained=null;
try{
 await Promise.all([once(a.ws,'open'),once(b.ws,'open')]);
 const start=Date.now();a.send({type:'ping',sent:start});await until(()=>a.messages.some(m=>m.type==='pong'&&m.sent===start));const rtt=Date.now()-start;
 a.send({type:'create',school:0});const room=await until(()=>a.messages.find(m=>m.type==='room'));
 b.send({type:'join',code:room.code,school:4});
 await until(()=>a.messages.find(m=>m.type==='start'));await until(()=>b.messages.find(m=>m.type==='start'));
 const first=await until(()=>a.messages.find(m=>m.type==='state'));
 const p=first.state.players.find(p=>p.id==='p1');assert.ok(p);
 a.send({type:'input',x:1,y:0,angle:0,seq:1});
 await until(()=>a.messages.some(m=>m.type==='state'&&m.state.players.some(q=>q.id==='p1'&&q.x>p.x+.1)));
 const before=a.messages.filter(m=>m.type==='state').length;
 a.send({type:'action',action:'press',slot:0,seq:2});
 await new Promise(r=>setTimeout(r,250));
 a.send({type:'action',action:'release',slot:0,seq:3});
 await until(()=>a.messages.filter(m=>m.type==='state').length>before+5);
 for(const c of [a,b])await until(()=>c.messages.some(m=>m.type==='state'&&m.state.events.some(e=>e.type==='cast'&&e.owner==='p1'&&e.slot===0)));
 if(process.argv.includes('--sustain')){
  let seqA=3,seqB=0,tick=0;const began=performance.now(),count=a.arrivals.length;
  const stream=setInterval(()=>{
   a.send({type:'input',x:0,y:0,angle:-Math.PI/2,seq:++seqA});
   b.send({type:'input',x:0,y:0,angle:Math.PI/2,seq:++seqB});
   if(tick%15===0){a.send({type:'action',action:'basic',seq:++seqA});b.send({type:'action',action:'basic',seq:++seqB});}
   if(tick%90===0){a.send({type:'action',action:'press',slot:0,seq:++seqA});b.send({type:'action',action:'press',slot:0,seq:++seqB});}
   if(tick%90===20){a.send({type:'action',action:'release',slot:0,seq:++seqA});b.send({type:'action',action:'release',slot:0,seq:++seqB});}tick++;
  },1000/30);
  try{await new Promise(r=>setTimeout(r,20000));}finally{clearInterval(stream);}
  const times=a.arrivals.slice(count),gaps=times.slice(1).map((v,i)=>v-times[i]);
  assert.ok(times.length>100,'Sustained authoritative snapshots must keep arriving');
  sustained={seconds:20,snapshots:times.length,receivedHz:Math.round(times.length*100000/(performance.now()-began))/100,maxGapMs:Math.round(Math.max(...gaps))};
 }
 b.ws.close();await until(()=>a.messages.some(m=>m.type==='opponent_left'));
 console.log(JSON.stringify({ok:true,origin:base,rttMs:rtt,sustained,checks:['HTTPS health','HTML','two WebSocket clients','friend room join','authoritative movement','skill event delivered to both players','disconnect notification']},null,2));
}finally{a.ws.terminate();b.ws.terminate();}
